const email = 'leg4cyl1nk@gmail.com' 
const clientId = '633859792101-pdlphii7bafgmgi1apjg32kj1n4134eg.apps.googleusercontent.com'

const clientSecret = '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'
const refreshToken = '1//04XQf8rCVAul7CgYIARAAGAQSNwF-L9IrRUeS9Ok63ZATWA5r8q8uD838a5f4HsPhLj3HyvCKXJlp8kNMidlSRa1cSf5TQP1LcH8'
const redirectUri = 'https://developers.google.com/oauthplayground';

module.exports = {
    email,
    clientId,
    clientSecret,
    refreshToken,
    redirectUri
};